Referências:

1. [A tabu search heuristic for the Equitable Coloring Problem, I. M´endez D´ıaz, G. Nasini and D. Sever´ın1](https://arxiv.org/abs/1405.7020v1#:~:text=In%20this%20paper%20we%20present%20a%20tabu%20search,equity%20constraints%2C%20new%20local%20search%20criteria%20are%20given)
2. [Using tabu search techniques for graph coloring. Computing,  Hertz A., de Werra D.](https://www.researchgate.net/publication/37437164_Werra_D_Using_Tabu_Search_Techniques_for_Graph_Coloring_Computing_39_345-351)
